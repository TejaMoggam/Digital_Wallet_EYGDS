Digital Payment Wallet - MERN Stack

A digital payment wallet built with the MERN stack. Users can add funds, send payments, and view transaction history.


